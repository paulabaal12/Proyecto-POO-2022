public class Datos_Registrador {

        private String Usuario;
        private String Contraseña;
        
        public String getContraseña() {
            return Contraseña;
        }
        public void setContraseña(String contraseña) {
            Contraseña = contraseña;
        }
        public String getUsuario() {
            return Usuario;
        }
        public void setUsuario(String usuario) {
            Usuario = usuario;
        }
    
    
}
