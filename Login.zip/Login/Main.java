import javax.sound.sampled.SourceDataLine;

public class Main {
    public static void main(String[] args){
    Registrador registrador = new Registrador();
    registrador.registra();
  //  registrador.Datos_Registrados();
    
    }
}
